from pathlib import Path

import pytest

from rl.evaluation.runners.feedback_regression import serving_library_environment
from rl.evaluation.runners.formal_v26_matched_eval import sha256_file


def test_library_environment_is_opt_in(monkeypatch):
    monkeypatch.delenv("TRITON_LIBCUDA_PATH", raising=False)
    assert serving_library_environment() == {"environment": {}, "driver": None}


def test_library_environment_records_existing_link_without_modification(tmp_path, monkeypatch):
    driver = tmp_path / "libcuda.so.1"
    driver.write_bytes(b"test fixture, not a CUDA library")
    link = tmp_path / "libcuda.so"
    link.symlink_to(driver)
    monkeypatch.setenv("TRITON_LIBCUDA_PATH", str(tmp_path))
    audit = serving_library_environment()
    assert audit["environment"] == {"TRITON_LIBCUDA_PATH": str(tmp_path)}
    assert audit["driver"] == {"link": str(link), "resolved": str(driver), "sha256": sha256_file(driver)}
    assert link.is_symlink() and Path(audit["driver"]["resolved"]) == driver


def test_library_environment_rejects_missing_link(tmp_path, monkeypatch):
    monkeypatch.setenv("TRITON_LIBCUDA_PATH", str(tmp_path))
    with pytest.raises(FileNotFoundError, match="no usable libcuda.so"):
        serving_library_environment()
    assert not list(tmp_path.iterdir())
